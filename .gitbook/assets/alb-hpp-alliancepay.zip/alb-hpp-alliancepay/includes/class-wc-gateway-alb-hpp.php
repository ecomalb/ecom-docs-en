<?php

use Automattic\WooCommerce\Enums\OrderInternalStatus;

if (!defined('ABSPATH')) exit;

class WC_Gateway_ALB_HPP extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'alliance_pay';
        $this->method_title       = 'AlliancePay';
        $this->method_description = 'Оплата через Hosted Payment Page Альянс Банку';
        $this->has_fields         = true;

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option('title', 'AlliancePay');
        $this->description = $this->get_option('description', 'Оплата через Альянс Банк.');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => 'Увімкнути/Вимкнути',
                'type'    => 'checkbox',
                'label'   => 'Увімкнути цей платіжний метод',
                'default' => 'yes',
            ],
        ];
    }

    public function payment_fields() {
        echo '<p>Оплатити за допомогою AlliancePay картками Visa або Mastercard</p>';
    }

    public function process_payment($order_id) {
        global $wpdb;
        $order = wc_get_order($order_id);

        $opt = get_option(ALB_HPP_OPT, []);

        $opt['baseUrl']    = $opt['baseUrl']    ?? ALB_HPP_PROD_BASE;
        $opt['apiVersion'] = $opt['apiVersion'] ?? 'v1';
        $opt['language']   = $opt['language']   ?? 'uk';

        try {
            $client = new \ALB\AlbHppClient($opt);

            $amount = max(10, $order->data['total']);
            $coinAmount = $amount * 100;

            $merchantRequestId = wp_generate_uuid4();
            $current_user_id = get_current_user_id();
            $sender_customer_id = (string)$current_user_id;

            if (!$sender_customer_id) {
                $sender_customer_id = 'not_auth_' . wp_generate_uuid4();
            }

            $params = [
                'coinAmount'       => $coinAmount,
                'paymentMethods'   => ['CARD','APPLE_PAY','GOOGLE_PAY'],
                'language'         => 'uk',
                'successUrl'       => $opt['successUrl'] ?? home_url('/'),
                'failUrl'          => $opt['failUrl']    ?? home_url('/'),
                'notificationUrl'  => home_url('/?alliance_pay_callback_notify'),
                'merchantRequestId'=> $merchantRequestId,
                'customerData'     => [
                    'senderCustomerId' => $sender_customer_id
                ],
            ];

            $res = $client->create_hpp_order($params);
        } catch (\Throwable $e) {
            return new \WP_REST_Response(['ok' => false, 'error' => $e->getMessage()], 500);
        }

        $table = self::table_alliance_checkout_integration_order();
        $paymentMethods = json_encode($res['paymentMethods']);

        $wpdb->insert($table, [
            'order_id'            => $order_id,
            'merchant_request_id' => $merchantRequestId,
            'hpp_order_id'        => $res['hppOrderId'] ?? null,
            'merchant_id'         => $res['merchantId'],
            'coin_amount'         => $res['coinAmount'] ?? null,
            'hpp_pay_type'        => $res['hppPayType'] ?? null,
            'order_status'        => $res['orderStatus'] ?? null,
            'payment_methods'     => $paymentMethods,
            'create_date'         => $res['createDate'] ?? null,
            'expired_order_date'  => $res['expiredOrderDate'] ?? null,
        ]);

        if (!empty($res['redirectUrl'])) {
            $order->payment_complete();
            WC()->cart->empty_cart();

            return [
                'result'   => 'success',
                'redirect' => $res['redirectUrl'],
            ];
        }

        return new \WP_REST_Response(['ok' => false, 'error' => 'Сталась технічна помилка'], 500);
    }

    public static function table_alliance_checkout_integration_order(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'alliance_checkout_integration_order';
    }

    public function callback($data, $raw)
    {
        global $wpdb;
        $table = self::table_alliance_checkout_integration_order();

        $alliance_order = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE hpp_order_id = %s",
                $data['hppOrderId']
            )
        );

        $wp_order = wc_get_order($alliance_order->order_id);

        if (!$wp_order || !$alliance_order){
            return false;
        }

        if ($alliance_order->is_callback_returned){
            return false;
        }

        if (isset($data['orderStatus']) && $data['orderStatus'] == 'SUCCESS'){
            $wp_order->update_status(OrderInternalStatus::COMPLETED, 'Оплата отримана через AlliancePay');
        }

        if (isset($data['orderStatus']) && $data['orderStatus'] != 'SUCCESS'){
            $wp_order->update_status(OrderInternalStatus::FAILED, 'Оплата отримана через AlliancePay');
        }

        $wpdb->update(
            $table,
            [
                'ecom_order_id' => $data['ecomOrderId'] ?? null,
                'is_callback_returned' => true,
                'callback_data' => $raw,
                'order_status' => $data['orderStatus'],
                'updated_at'    => current_time('mysql'),
            ],
            [
                'hpp_order_id' => $data['hppOrderId'],
            ],
        );
    }

    public function dataForStatusDetail($order_id)
    {
        global $wpdb;

        $is_call_to_ecom = false;
        $table_alliance_checkout_integration_order = self::table_alliance_checkout_integration_order();
        $result = $wpdb->get_row("SELECT * FROM {$table_alliance_checkout_integration_order} WHERE order_id = {$order_id}");

        if (!$result) {
            echo '<h2>Це замовлення оплачено не через AlliancePay</h2>';
            return false;
        }

        // формуємо дані з БД, якщо отримали колбек від еКому
        if ($result->is_callback_returned){
            $callback_data = json_decode($result->callback_data);
            $status_url = $callback_data->statusUrl ?? null;
            $ecom_order_id = $result->ecom_order_id;
            $merchant_id = $result->merchant_id;
            $hpp_order_id = $result->hpp_order_id;
            $hpp_pay_type = $result->hpp_pay_type;
            $merchant_request_id = $result->merchant_request_id;
            $order_status = $result->order_status;
        }

        // формуємо дані прямим запитом до еКому, якщо дані не отримали
        if (!$result->is_callback_returned){
            $is_call_to_ecom = true;
            try {
                $client = new \ALB\AlbHppClient(get_option(ALB_HPP_OPT, []));
                $res = $client->get_order($result->hpp_order_id);
                $ecom_order_id = $res['ecomOrderId'];
                $status_url = $res['statusUrl'];
                $merchant_id = $res['merchantId'];
                $hpp_order_id = $res['hppOrderId'];
                $hpp_pay_type = $res['hppPayType'];
                $merchant_request_id = $res['merchantRequestId'];
                $order_status = $res['orderStatus'];
            } catch (\Throwable $e) {
                echo '<h2>Виникла помилка при зверненні до AlliancePay</h2>';
                return new \WP_REST_Response(['ok' => false, 'error' => $e->getMessage()], 500);
            }
        }

        echo '<div class="wrap">';
        echo '<h1>AlliancePay Order Status</h1>';
        echo '<div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; margin-top: 20px;">';
        echo '<h2 style="color: #2ea2cc;">Деталі по оплаті через AlliancePay</h2>';

        echo '<p style="margin-top:20px;">';
        echo '<a href="' . admin_url('edit.php?post_type=shop_order') . '" class="button button-primary">⬅ Назад до списку замовлень</a>';
        echo '</p>';

        if ($order_id) {
            echo '<p><strong>Order ID:</strong> ' . $order_id . '</p>';

            $order = wc_get_order($order_id);
            if ($order) {
                echo '<p><strong>Woocommerce Order Status:</strong> ' . $order->get_status() . '</p>';
                echo '<p><strong>Order Total:</strong> ' . $order->get_formatted_order_total() . '</p>';
            }
        }

        if ($is_call_to_ecom) {
            echo '<h2 style="color: firebrick">Колбек від AllianceBank не отримано. Дані нижче на пряму взятті з AlliancePay</h2>';
        } else {
            echo '<h2 style="color: green">Колбек від AllianceBank отримано. Дані нижче отримано з колбеку і завантажено в БД</h2>';
        }

        echo '<p><strong>ecomOrderId:</strong> ' . $ecom_order_id . '</p>';
        echo '<p><strong>merchantId:</strong> ' . $merchant_id . '</p>';
        echo '<p><strong>hppOrderId:</strong> ' . $hpp_order_id . '</p>';
        echo '<p><strong>hppPayType:</strong> ' . $hpp_pay_type . '</p>';
        echo '<p><strong>merchantRequestId:</strong> ' . $merchant_request_id . '</p>';
        echo '<p><strong>AlliancePay orderStatus:</strong> ' . $order_status . '</p>';
        echo '<p><strong>statusUrl:</strong> <a href='.  $status_url .' target="_blank">' . $status_url . '</a></p>';

        echo '</div>';
        echo '</div>';
    }
}
