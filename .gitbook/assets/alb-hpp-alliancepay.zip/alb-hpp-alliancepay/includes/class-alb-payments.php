<?php
if (!defined('ABSPATH')) exit;

class ALB_Payments {
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'alliance_checkout_integration_order';
    }

    /** Створення таблиці (викликати під час активації) */
    public static function create_table() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table_alliance_checkout_integration_order = self::table();

        $sql = ("CREATE TABLE IF NOT EXISTS {$table_alliance_checkout_integration_order}
		(
			`order_id` INT(11) NOT NULL,
			`merchant_request_id` VARCHAR(255) NOT NULL,
			`hpp_order_id` VARCHAR(255) NOT NULL,
			`merchant_id` VARCHAR(255) NOT NULL,
			`coin_amount` INT(11) NOT NULL,
			`hpp_pay_type` VARCHAR(50) NOT NULL,
			`order_status` VARCHAR(50) NOT NULL,
			`payment_methods` TEXT NOT NULL,
			`create_date` DATETIME NOT NULL,
            `updated_at` DATETIME,
            `operation_id` VARCHAR(255),
            `ecom_order_id` VARCHAR(255),
            `is_callback_returned` BOOLEAN DEFAULT FALSE,
            `callback_data` LONGTEXT,
			`expired_order_date` DATETIME NOT NULL,
			PRIMARY KEY (`order_id`),
			KEY `merchant_request_id` (`merchant_request_id`),
			KEY `hpp_order_id` (`hpp_order_id`),
			KEY `merchant_id` (`merchant_id`),
			KEY `order_id` (`order_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;");

        dbDelta($sql);
    }
}
