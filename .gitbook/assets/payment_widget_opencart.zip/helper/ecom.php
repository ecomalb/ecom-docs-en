<?php

namespace Helper;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use SimpleJWT\JWE;
use SimpleJWT\Keys\KeyFactory;
use SimpleJWT\Keys\KeySet;

class Ecom
{
	const AUTHORIZE_VIRTUAL_DEVICE = 'api-gateway/authorize_virtual_device';
	const CREATE_ORDER = 'ecom/execute_request/hpp/v1/create-order';
	const CHECK_OPERATIONS = 'ecom/execute_request/hpp/v1/operations';
	const METHOD_POST = 'POST';
	const BASE_URL_PROD = 'https://api-ecom-prod.bankalliance.ua/';
	const ALGORITHM = 'ECDH-ES+A256KW';
	private Client $client;
	private ?object $config;

	public function __construct(?object $config = null)
	{
		$this->client = new Client(['base_uri' => self::BASE_URL_PROD]);
		$this->config = $config;
	}

	/**
	 * @throws GuzzleException
	 * @throws Exception
	 */
	public function authorizeByVirtualDevice(string $payment_alliance_service_code_id)
	{
		try {
			$response = $this->client->request(self::METHOD_POST, self::AUTHORIZE_VIRTUAL_DEVICE, [
				'headers' => $this->getHeaders(),
				'json' => [
					'serviceCode' =>  $payment_alliance_service_code_id,
				]
			]);
		} catch (GuzzleException $e) {
			throw new Exception('authorize error');
		}

		$contents = $response->getBody()->getContents();
		$contents = json_decode($contents, true);

		if (!isset($contents['jwe'])) {
			throw new Exception('no_token');
		}

		return $contents['jwe'];
	}

	public function decryptAuthResponse(string $jwe_token): array
	{
		require_once (DIR_EXTENSION . '/alliance/system/library/simplejwt-master/init.php');

		$set = new KeySet();
		$keyFactory = new KeyFactory();

		$json = [
			"kty" => "EC",
			"d" => $this->config->get("payment_alliance_jwt_param_d"),
			"use" => "enc",
			"crv" => "P-384",
			"x" => $this->config->get("payment_alliance_jwt_param_x"),
			"y" => $this->config->get("payment_alliance_jwt_param_y"),
			"alg" => self::ALGORITHM,
		];

		$keys = $keyFactory->create($json, alg: self::ALGORITHM);
		$set->add($keys);

		$jwe_decrypted = JWE::decrypt($jwe_token, $set, self::ALGORITHM);

		return (array) json_decode($jwe_decrypted->getPlaintext());
	}

	/**
	 * @throws Exception
	 */
	public function createCardHppOrder(array $decrypt_auth, object $session, object $config, $url, $total_price)
	{
		try {
			$response = $this->client->request(self::METHOD_POST, self::CREATE_ORDER, [
				'headers' => $this->getHeaders($decrypt_auth),
				'json' => $this->collectPaymentData($session, $config, $url, $total_price),
			]);
		} catch (GuzzleException $e) {
			throw new Exception('create order error');
		}

		$contents = $response->getBody()->getContents();

		return json_decode($contents, true);
	}

	/**
	 * @throws Exception
	 */
	public function checkOperationStatus(array $decrypt_auth, string $hpp_order_id)
	{
		try {
			$response = $this->client->request(self::METHOD_POST, self::CHECK_OPERATIONS, [
				'headers' => $this->getHeaders($decrypt_auth),
				'json' => [
					"hppOrderId" => $hpp_order_id,
				]
			]);
		} catch (GuzzleException $e) {
			throw new Exception('check operation error');
		}

		$contents = $response->getBody()->getContents();

		return json_decode($contents, true);
	}

	private function collectPaymentData(object $session, object $config, $url, $total_price): array
	{
		if (!isset($session->data['customer']['customer_id'])){
			$customer_id = 'not_authorized_' . uniqid();
		} else {
			$customer_id = 'id_' . $session->data['customer']['customer_id'];
		}

		return [
			"merchantId" => $config->get("payment_alliance_merchant_id"),
			"hppPayType" => "PURCHASE",
			"failUrl" => $config->get("payment_alliance_fail_url"),
			"successUrl" => $config->get("payment_alliance_success_url"),
			"merchantRequestId" => uniqid(),
			"statusPageType" => "STATUS_TIMER_PAGE",
			"paymentMethods" => [
				"CARD", "APPLE_PAY"
			],
			"customerData" => [
				"senderCustomerId" => $customer_id,
			],
			"coinAmount" => (int)($total_price * 100),
			"notificationUrl" => $url->link('index.php?route=extension/alliance/payment/alliance|notifyCallback')
		];
	}

	private function getHeaders(array $decrypt_auth = []): array
	{
		$headers["Accept"] = "application/json";
		$headers["Content-Type"] = "application/json";
		$headers["x-api_version"] = "v1";
		$headers["x-request_id"] = uniqid();

		if ($decrypt_auth) {
			$headers['x-device_id'] = $decrypt_auth['deviceId'];
		}

		if ($decrypt_auth) {
			$headers['x-refresh_token'] = $decrypt_auth['refreshToken'];
		}

		return $headers;
	}
}
