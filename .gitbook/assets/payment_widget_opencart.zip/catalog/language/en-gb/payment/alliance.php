<?php

$_["heading_title"] = "Alliance";
$_["text_title"] = "AlliancePay";
$_["log_error_install"] =
    "Alliance payment extension was not installed correctly or the files are corrupt. Please reinstall the extension. If this message persists after a reinstall, contact support with this message.";
$_["error_order_not_found"] = "Order not found";
$_["error_token_not_found"] = "Payment token not found";
