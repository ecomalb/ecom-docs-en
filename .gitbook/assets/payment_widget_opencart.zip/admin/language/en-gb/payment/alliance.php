<?php
$_["heading_title"] = "Alliance Payment";

// Text
$_["text_payment"] = "Payment";
$_["text_success"] = "Success: You have modified Alliance payment module!";
$_["text_edit"] = "Edit Alliance Settings";
$_["text_changes"] = "There are unsaved changes.";
$_["text_general"] = "General";
$_["text_statuses"] = "Order Statuses";
$_["text_advanced"] = "Advanced";
$_["text_all_geo_zones"] = "All Geo Zones";
$_["text_yes"] = "Yes";
$_["text_no"] = "No";
$_["text_are_you_sure"] = "Are you sure?";

// Tab
$_["tab_settings"] = "Settings";
$_["tab_log"] = "Log";
$_["tab_support"] = "Support";

// Button
$_["button_disconnect"] = "Disconnect";
$_["button_send"] = "Send";
$_["button_continue"] = "Continue";

//Alliance
$_["alliance_service_code_id_api_key"] = "serviceCode:";
$_["merchant_request_id_key"] = "merchantRequestId:";
$_["merchant_id_key"] = "merchantId:";
$_["fail_url_key"] = "fail_url:";
$_["success_url_key"] = "success_url:";

// Entry
$_["entry_ipn_url"] = "IPN Url";
$_["entry_api_key"] = "API Code:";
$_["entry_api_key_1"] = "merchantRequestId test";
$_["alliance_merchant_request_id_api_key"] = "merchantRequestId";
$_["merchant_id_key"] = "merchantId:";
$_["notification_url_key"] = "notification_url:";
$_["entry_ipn_key"] = "IPN Key:";
$_["entry_geo_zone"] = "Geo Zone";
$_["entry_status"] = "Status";
$_["entry_sort_order"] = "Sort Order";
$_["entry_paid_status"] = "Paid Status";
$_["entry_pending_status"] = "Pending Status";
$_["entry_return_url"] = "Return URL";
$_["entry_debug"] = "Debug Logging";

// Help
//$_["help_api_key"] = "Get your API Code from your PTPShopy account";
//$_["help_ipn_key"] = "Get your IPN Key from your PTPShopy account";
//$_["help_paid_status"] = "A fully paid invoice";
//$_["help_pending_status"] =
//    "Buyer has checked out and we are awaiting funds from the buyer";
//$_["help_ipn_url"] =
//    'Copy this url to "IPN Url" field on <a target="_blank" href="https://merchant.ptpshopy.com/?from=opencart-3">merchant.ptpshopy.com</a>';
//$_["help_return_url"] =
//    "PTPShopy will provide a redirect link to the user for this URL";
//$_["help_debug"] =
//    "Enabling debug will write sensitive data to a log file. You should always disable unless instructed otherwise";

// Success
$_["success_clear"] = "Success: Alliance log has been cleared";

// Warning
$_["warning_permission"] =
    "Warning: You do not have permission to modify Alliance payment module.";

// Error
$_["error_api_key"] = "You must specify your API code";
$_["error_ipn_key"] = "You must specify your IPN key";
$_["error_ipn_url"] = "`IPN URL` needs to be a valid URL";
$_["error_return_url"] = "`Return URL` needs to be a valid URL";

// Log
$_["log_error_install"] =
    "Alliance payment extension was not installed correctly or the files are corrupt. Please reinstall the extension. If this message persists after a reinstall, contact support with this message.";
