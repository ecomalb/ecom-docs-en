<?php
namespace Opencart\Admin\Controller\Extension\Alliance\Payment;

use Helper\Ecom;

class Alliance extends \Opencart\System\Engine\Controller
{
	private array $events = [
		[
			'description' => 'Order info',
			'trigger' => 'admin/view/sale/order_info/before',
			'action' => 'extension/alliance/payment/alliance|operationsEvent',
			'event_code' => 'alliance_operations',
		],
	];

    public function index(): void
    {
        $this->load->language("extension/alliance/payment/alliance");
        $this->load->model("setting/setting");
		$this->load->model('extension/alliance/payment/data');
		$this->document->setTitle($this->language->get("heading_title"));

        if (
            $this->request->server["REQUEST_METHOD"] == "POST" &&
            $this->request->post["action"] === "save"
        ) {
            $this->model_setting_setting->editSetting(
                "payment_alliance",
                $this->request->post
            );
            $this->session->data["success"] = $this->language->get(
                "text_success"
            );
            $this->response->redirect(
                $this->url->link(
                    "extension/alliance/payment/alliance",
                    "user_token=" . $this->session->data["user_token"],
                    "SSL"
                )
            );
        }

		$data = $this->model_extension_alliance_payment_data->fillSettingData($this->session, $this->config, $this->request);

        $this->response->setOutput($this->load->view("extension/alliance/payment/alliance", $data));
    }

    public function install(): void
    {
        $this->load->language("extension/alliance/payment/alliance");
        $this->load->model("localisation/order_status");
		$this->load->model("setting/setting");
		$this->load->model('extension/alliance/payment/alliance');
		$this->load->model('extension/alliance/payment/db');

        $default_pending = 1;
        $default_paid = 7;
        $default_error = 10;

        $default_settings = [
            "payment_alliance_paid_status" => $default_paid,
            "payment_alliance_pending_status" => $default_pending,
            "payment_alliance_error_status" => $default_error,
            "payment_alliance_return_url" => null,
            "payment_alliance_debug" => "0",
            "payment_alliance_version" => "0.0.1",
        ];

		$this->model_setting_setting->editSetting("alliance", $default_settings);
		$this->model_extension_alliance_payment_db->initDB();
		$this->installEvents();
    }

	public function uninstall(): void
	{
		$this->load->language('extension/report');
		$this->load->model('extension/alliance/payment/alliance');
		$this->load->model('setting/extension');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/report')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->model_setting_extension->uninstall('report', $this->request->get['code']);
			// Call uninstall method if it exists
			//$this->load->controller('extension/' . $this->request->get['extension'] . '/report/' . $this->request->get['code'] . '.uninstall');

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function installEvents(): void
	{
		$this->load->model('setting/event');

		$defaults = [
			'status' => 1,
			'sort_order' => 0,
			'description' => '',
		];

		foreach ($this->events as $event) {
			$this->model_setting_event->deleteEventByCode($event['event_code']);
			$event['code'] = $event['event_code'];
			// add default keys in array
			foreach ($defaults as $key => $value) {
				if (!isset($event[$key])) {
					$event[$key] = $value;
				}
			}

			if (VERSION > '4.0.1.1') {
				$event['trigger'] = str_replace('|', '.', $event['trigger']);
				$event['action'] = str_replace('|', '.', $event['action']);
			}

			$this->model_setting_event->addEvent([
				'code' => $event['event_code'],
				'trigger' => $event['trigger'],
				'action' => $event['action'],
				'description' => $event['description'],
				'status' => $event['status'],
				'sort_order' => $event['sort_order'],
			]);
		}
	}

	public function operationsEvent(string &$route, array &$data, string &$code): void
	{
		$this->load->model('extension/alliance/payment/alliance');
		$alliance_order = $this->model_extension_alliance_payment_alliance->getAllianceOrder($data['order_id']);

		if (empty($alliance_order)) {
			return;
		}

		$data['text_form'] .= ' ' . "<a class='btn btn-primary' style='float:right' href=index.php?route=extension/alliance/payment/alliance|checkOperationStatus&user_token=".$this->session->data['user_token']."&order_id=".$data['order_id'].">Провірити статус замовлення</a>";
	}

	public function checkOperationStatus(): bool
	{
		require_once (DIR_EXTENSION . '/alliance/helper/ecom.php');

		$this->load->model("setting/setting");
		$this->load->model('extension/alliance/payment/alliance');
		$this->load->language("extension/alliance/payment/alliance");
		$this->document->setTitle('Отримання даних по замовленню');

		$referer = $this->request->server['HTTP_REFERER'] ?? $this->url->link('common/dashboard');
		$order_id = $this->request->get('order_id');
		$data["heading_title"] = 'Отримання даних по замовленню';
		$data["header"] = $this->load->controller("common/header");
		$data["column_left"] = $this->load->controller("common/column_left");
		$data["footer"] = $this->load->controller("common/footer");
		$data["back"] = $referer;

		$alliance_order = $this->model_extension_alliance_payment_alliance->getAllianceOrder($order_id);
		$order_callback = $this->model_extension_alliance_payment_alliance->getAllianceOrderCallback($order_id);

		if (!empty($alliance_order) && !empty($order_callback)) {
			$this->response->setOutput(
				$this->load->view("extension/alliance/payment/operation_info",
				$this->model_extension_alliance_payment_alliance->fillOperationStatusData($data, $order_callback, false))
			);

			return true;
		}

		try {
			$ecom = new Ecom($this->config);
			$jwe_token = $ecom->authorizeByVirtualDevice($this->config->get("payment_alliance_service_code_id"));
			$decrypt_auth = $ecom->decryptAuthResponse($jwe_token);

			$e_com_response = $ecom->checkOperationStatus($decrypt_auth, $alliance_order['hpp_order_id']);
		} catch (\Exception $exception) {
			$json['msgType'] = 'Сталась технічна помилка';
			$this->response->setOutput(
				$this->load->view("extension/alliance/payment/operation_info",
				$this->model_extension_alliance_payment_alliance->fillOperationStatusData($data, $json, true))
			);

			return false;
		}

		if (
			isset($e_com_response['msgType'])
			&&
			(strpos($e_com_response['msgType'], 'ERROR') || strpos($e_com_response['msgType'], 'error'))
		) {
			$this->response->setOutput(
				$this->load->view("extension/alliance/payment/operation_info",
				$this->model_extension_alliance_payment_alliance->fillOperationStatusData($data, $e_com_response, true))
			);

			return false;
		}

		$this->response->setOutput(
			$this->load->view("extension/alliance/payment/operation_info",
			$this->model_extension_alliance_payment_alliance->fillOperationStatusData($data, $e_com_response, false))
		);

		return true;
	}
}
